
from flask import Flask, request
import pandas as pd
import numpy as np
import json
import pickle
import os

app = Flask(__name__)
# Load Model and Scaler Files
with open(str(os.getcwd() + '\\IrisClassifier.pkl'), 'rb') as pickle_file:
    model = pickle.load(pickle_file)

def returnPrediction(i):
    predictvalues = ['Iris-Setosa','Iris-Versicolour','Iris-Virginica']
    return predictvalues[i]
    
@app.route('/api', methods=['POST'])
def Make_Iris_Prediction():
    data = json.dumps(request.get_json(force=True)).replace('[','').replace(']','').split(',')
    y = []
    for x in data:
        y.append(float(x))
    i = model.predict([[y[0], y[1] , y[2], y[3]]])[0]
    #                    sl , sw   , pl  , pw
    return str(returnPrediction(i))
 
if __name__ == '__main__':
    # host flask app at port 10001
    app.run(port=10001, debug=True)
